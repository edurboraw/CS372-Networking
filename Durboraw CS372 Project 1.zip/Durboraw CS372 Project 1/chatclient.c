#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <string.h>
#include <sys/types.h>
#include <netdb.h>



/************************************************************************************
This funciton will set up the socket with the passed addrinfo
*************************************************************************************/

int setSocket(struct addrinfo * res) {
	int sockit;
	if ((sockit = socket(res->ai_family, res->ai_socktype, res->ai_protocol)) == -1) {
		printf("error");
		exit(1);
	}
	return sockit;
}

/************************************************************************************
This function will create a connection with the server and will
start the conversation.
*************************************************************************************/

void chat(int sockit, char * un, char * server) {
	char input[503], output[501];
	int bytesSent = 0;
	int status;
	//clear the memory
	memset(input, 0, sizeof(input));
	memset(output, 0, sizeof(output));
	fgets(input, 500, stdin);
	while (1) {
		printf("%s>", un);
		fgets(input, 502, stdin);
		//see if the user wants to quit
		if (strcmp(input, "\\quit\n") == 0) {
			break;
		}
		//send chat message
		bytesSent = send(sockit, input, strlen(input), 0);
		if (bytesSent == -1) { //if nothing sent, then it's an error
			printf("Error\n");
			exit(1);
		}
		//receive message
		status = recv(sockit, output, 500, 0);
		if (status == -1) {
			printf("Error\n");
			exit(1);
		}
		else if (status == 0) {
			printf("Connection close");
		}
		else {
			printf("%s> %s\n", server, output);//print message if successful
		}
		//clear memory to start again
		memset(input, 0, sizeof(input));
		memset(output, 0, sizeof(output));
	}
	close(sockit);
	printf("Connection Closed\n");

}

/****************************************************************************************
Sets up the connection between client and server given the socket, username and servername
*****************************************************************************************/

void connSetup(int sockit, char* un, char* server) {
	int status = send(sockit, un, strlen(un), 0);
	int recStatus = recv(sockit, server, 10, 0);
}


/**************************************************************************************
This function will receive pointers to address and port, add the family and socktype
and call getaddrinfo. If successful will return a pointer to res 
**************************************************************************************/

struct addrinfo * addr_info_call(char * addr_in, char * port) {
	int status;
	struct addrinfo hint;
	struct addrinfo * res;

	//replaces existing numbers with 0
	memset(&hint, 0, sizeof hint);

	//append sockaddr info
	hint.ai_family = AF_INET;
	hint.ai_socktype = SOCK_STREAM;

	if ((status = getaddrinfo(addr_in, port, &hint, &res)) != 0) {
		printf("Fail\n");
		exit(1);
	}

	return res;
}


/**************************************************************************************
This function will set the users name
**************************************************************************************/
void setUName(char * name) {
	printf("Enter a 10 char name: ");
	scanf("%s", name);
}

/**************************************************************************
 This funciton will connect the socket to the pertinent address info
**************************************************************************/

void conn_sock(int sockit, struct addrinfo * res){
	int status;
	if((status = connect(sockit, res->ai_addr, res->ai_addrlen)) == -1){
		printf("Error\n");
		exit(1);
	}

}

/*************************************************************************************
This is the main function...it calls the functions and ties it all together
**************************************************************************************/
int main(int argc, char *argv[]) {
	if (argc != 3) {
		printf("Argument Error\n");
		exit(1);
	}
	//set up variables
	char un[10];
	char server[10];
	//call get setUName to get the un
	setUName(un);
	struct addrinfo *res = addr_info_call(argv[1], argv[2]);
	int sockit = setSocket(res);
	printf("stop 1\n");//test
	conn_sock(sockit, res);
	printf("stop 1.5\n");
	connSetup(sockit, un, server);
	printf("stop 2\n");//test
	chat(sockit, un, server);
	printf("stop 3\n");//test
	freeaddrinfo(res);

}
