#!/usr/bin/python

from socket import*

import sys

#This will set up the chat function
def chat(sockit, client, un):
    while 1:
        received = sockit.recv(501)[0:-1]

        if received =="":
            print("Nothing Received\nConneciton Closed\nWaiting on a new Connection\n")
            break

        #formatted printing
        print("{}> {}".format(client, received))

        send = ""
        while len(send) == 0 or len(send) > 500:
            send = raw_input("{}> ".format(un))
        if send == "\quit":
            print("Connection closed\nAwaiting new Conneciton")
            break
        sockit.send(send)

"""this will perform the handshake functions in setting up the connection"""
def ConnSetUp(sockit, un):
    #receive from client
    client = sockit.recv(1024)
    sockit.send(un)
    return client

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Please specify port")
        exit(1)

    sport = sys.argv[1]
    ssocket = socket(AF_INET, SOCK_STREAM)
    ssocket.bind(('', int(sport)))
    ssocket.listen(1)

    un = ""
    #Verify that the username is of the right size
    while len(un) == 0 or len(un) > 10:
        un = raw_input("Enter user name of 10 characters or fewer: ")
        print("Server Ready\n")
    
    while 1:
        sockit, address = ssocket.accept()
        print("receive connection\n")
        #start sending and receiving messages
        chat(sockit, ConnSetUp(sockit, un), un)
        sockit.close()
