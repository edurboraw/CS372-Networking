#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>

/**
* This function will set up the addrinfo struct
**/

struct addrinfo * create_addrinfo(char * port) {
	struct addrinfo hints;
	struct addrinfo * res;
	int status;

	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;

	if ((status = getaddrinfo(NULL, port, &hints, &res)) != 0) {
		printf("Error 1\n");
		exit(1);
	}
	return res;
}

/**
* This function will create a an address/port pair stored in a linked list
**/

struct addrinfo * create_ip_port(char * ip, char * port) {
	int status;
	struct addrinfo hints;
	struct addrinfo *res;

	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;

	if ((status = getaddrinfo(ip, port, &hints, &res)) != 0) {
		printf("Error 2\n");
		exit(1);
	}
	return res;
}

/**
* This function will create the socket given addrinfo
**/

int make_socket(struct addrinfo * res) {
	int sockfd;
	if ((sockfd = socket((struct addrinfo *)(res)->ai_family, res->ai_socktype, res->ai_protocol)) == -1) {
		printf("Error 3\n");
		exit(1);
	}
	return sockfd;
}

/**
* This funciton will create the connection given the socket info
**/

void make_connection(int sockfd, struct addrinfo * res) {
	int status;
	if ((status = connect(sockfd, res->ai_addr, res->ai_addrlen)) == -1) {
		printf("Error 4\n");
		exit(1);
	}
}

/**
* This funciton will bind the socket to the port
**/

void bind_connection(int sockfd, struct addrinfo * res) {
	if (bind(sockfd, res->ai_addr, res->ai_addrlen) == -1) {
		close(sockfd);
		printf("Error 5\n");
		exit(1);
	}
}

/**
* This function will listen for incoming connection attempts
**/

void listen_for_comm(int sockfd) {
	if (listen(sockfd, 10) == -1) {
		close(sockfd);
		printf("Error 6\n");
		exit(1);
	}
}

/**
* This will create an array of strings for each file
**/

char ** create_sArray(int amt) {
	char ** sArray = malloc(amt * sizeof(char *));
	int x;
	for (x = 0; x < amt; x++) {
		sArray[x] = malloc(100 * sizeof(char));
		memset(sArray[x], 0, sizeof(sArray[x]));
	}
	return sArray;
}

/**
* This funciton will delete the array of strings created above
**/

void delete_sArray(char ** sArray, int amt) {
	int x;
	for (x = 0; x < amt; x++) {
		free(sArray[x]);
	}
	free(sArray);
}

/**
* This function will count files and place them into sArray
**/

int get_files(char ** files) {
	int x = 0;
	DIR * directory;
	struct dirent * dir;
	directory = opendir(".");
	if (directory) {
		while ((dir = readdir(directory)) != NULL) {
			if (dir->d_type == DT_REG) {
				strcpy(files[x], dir->d_name);
				printf("%s\n", files[x]);//test
				x++;
			}
		}
		closedir(directory);
	}
	return x;
}

/**
* this function validates the existence of a file
**/

int validate_file(char ** files, int total, char * filename) {
	int exists = 0;
	int x;
	for (x = 0; x < total; x++) {
		if (strcmp(files[x], filename) == 0) {
			exists = 1;
		}
	}
	return exists;
}

/**
* sends the file
**/

void send_file(char * address, char * port, char *fname) {
	sleep(2);
	struct addrinfo * res = create_ip_port(address, port);
	int skt = make_socket(res);
	make_connection(skt, res);
	char overflow[1000];
	memset(overflow, 0, sizeof(overflow));
	int desc = open(fname, O_RDONLY);
	while (1) {
		int bytesIn = read(desc, overflow, sizeof(overflow) - 1);
		if (bytesIn == 0) {
			break;
		}
		if (bytesIn < 0) {
			printf("Error 7\n");
			return;
		}
		void *z = overflow;
		while (bytesIn > 0) {
			int bytes_processed = send(skt, z, sizeof(overflow), 0);
			if (bytes_processed < 0) {
				printf("Error 8\n");
			}
			bytesIn = bytesIn - bytes_processed;
			z += bytes_processed;
		}
		memset(overflow, 0, sizeof(overflow));
	}
	memset(overflow, 0, sizeof(overflow));
	strcpy(overflow, "__done__");
	send(skt, overflow, sizeof(overflow), 0);
	close(skt);
	freeaddrinfo(res);
}

/**
* This function will send directory to client
**/

void send_dir(char *address, char * port, char ** files, int num) {
	sleep(2);
	struct addrinfo * res = create_ip_port(address, port);
	int sockit = make_socket(res);
	make_connection(sockit, res);

	int x;

	for (x = 0; x < num; x++) {
		send(sockit, files[x], 100, 0);
	}
	char * complete = "done";
	send(sockit, complete, strlen(complete), 0);
	close(sockit);
	freeaddrinfo(res); 
}

/**
* This function will handle from client
**/

void handle_new(int new_sockit) {
	char * good = "good";
	char * bad = "bad";
	char port[100];
	memset(port, 0, sizeof(port));
	recv(new_sockit, port, sizeof(port) - 1, 0);
	send(new_sockit, good, strlen(good), 0);
	char comm[100];
	memset(comm, 0, sizeof(comm));
	recv(new_sockit, comm, sizeof(comm) - 1, 0);
	send(new_sockit, good, strlen(good), 0);
	char address[100];
	memset(address, 0, sizeof(address));
	recv(new_sockit, address, sizeof(address) - 1, 0);
	printf("Good. Receiving from: %s\n", address);
	if (strcmp(comm, "l") == 0) {
		send(new_sockit, good, strlen(good), 0);
		printf("Sending file list\n");
		char ** files = create_sArray(100);
		int num = get_files(files);
		send_dir(address, port, files, num);
		delete_sArray(files, 100);
	}
	else if (strcmp(comm, "g") == 0) {
		send(new_sockit, good, strlen(good), 0);
		char fname[100];
		memset(fname, 0, sizeof(fname));
		recv(new_sockit, fname, sizeof(fname) - 1, 0);
		printf("File: %s requested\n", fname);
		char ** files = create_sArray(100);
		int num = get_files(files);
		int valid = validate_file(files, num, fname);
		if (valid) {
			printf("Valid File\n");
			char * file_found = "File found";
			send(new_sockit, file_found, strlen(file_found), 0);
			char new_fname[100];
			memset(new_fname, 0, sizeof(new_fname));
			strcpy(new_fname, "./");
			char * done = new_fname + strlen(new_fname);
			done += sprintf(done, "%s", fname);
			send_file(address, port, new_fname);
		}
		else {
			printf("File not found, Error\n");
			char * fnf = "File Not Found";
			send(new_sockit, fnf, 100, 0);
		}
		delete_sArray(files, 100);
	}
	else {
		send(new_sockit, bad, strlen(bad), 0);
		printf("Error 10\n");
	}
	printf("Waiting on additional requests\n");
}

/**
* This funciton will wait for and handle incoming transmission
**/

void wait(int sockit) {
	struct sockaddr_storage address;
	socklen_t addr_size;
	int new_sockit;

	while (1) {
		addr_size = sizeof(address);
		new_sockit = accept(sockit, (struct addrinfo *)&address, &addr_size);
		if (new_sockit == -1) {
			printf("Got it\n");//test
			continue;
		}
		printf("About to call\n");//test
		handle_new(new_sockit);
		close(new_sockit);
	}
}

/**
* This is the main function, it ties everything together
**/

int main(int argc, char *argv[]) {
	if (argc != 2) {
		printf("Error 11\n");
		exit(1);
	}
	printf("Server listening on port %s\n", argv[1]);
	struct addrinfo * res = create_addrinfo(argv[1]);
	int sockit = make_socket(res);
	bind_connection(sockit, res);
	listen_for_comm(sockit);
	wait(sockit);
	freeaddrinfo(res);
}