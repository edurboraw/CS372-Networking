#!/bin/python
from socket import *
import sys

def verify_inputs():
    if len(sys.argv) < 5 or len(sys.argv) > 6:
        print("ERROR: Not Enough Arguments\n")
        exit(1)
    elif sys.argv[1] != "flip1" and sys.argv[1]!="flip2" and sys.argv[1]!="flip3":
        print("Error: Bad Server Name\n")
        exit(1)
    elif int(sys.argv[2]) > 65535 or int(sys.argv[2])< 1024:
        print("Error: Bad Port\n")
        exit(1)
    elif sys.argv[3] != "-l" and sys.argv[3] != "-g":
        print("Error: Invalid option\n")
        exit(1)
    elif sys.argv[3] == "-l" and (int(sys.argv[4])>65535 or int(sys.argv[4])<1024):
        print("Error: Bad Port\n")
        exit(1)
    elif sys.argv[3] == "-g" and (int(sys.argv[5]) > 65535 or int(sys.argv[5]) < 1024):
        print("Error: Bad Port\n")
        exit(1)

def setup_socket():
    if sys.argv[3] == "-l":
        port = 4
    elif sys.argv[3] == "-g":
        port = 5

    sPort = int(sys.argv[port])
    sSockit = socket(AF_INET, SOCK_STREAM)
    sSockit.bind(('', sPort))
    sSockit.listen(1)
    dSockit, address = sSockit.accept()
    return dSockit

def get_flist(sockit):
    fname = sockit.recv(100)
    while fname != "done":
        print(fname)
        fname = sockit.recv(100)

def get_file(sockit):
    file = open(sys.argv[4], "w")
    buffer = sockit.recv(1000)
    while "done" not in buffer:
        file.write(buffer)
        buffer = sockit.recv(1000)

def get_ip():
    sockit = socket(AF_INET, SOCK_DGRAM)
    sockit.connect(("8.8.8.8", 80))
    return sockit.getsockname()[0]

def send_rec(sockit):
    if sys.argv[3] == "-l":
        print("File list request:")
        port = 4
    elif sys.argv[3] == "-g":
        print("File Request:")
        port = 5
    sockit.send(sys.argv[port])
    sockit.recv(1024)
    if sys.argv[3] == "-l":
        sockit.send("l")
    else:
        sockit.send("g")
    sockit.recv(1024)
    address = get_ip()
    sockit.send(address)
    resp = sockit.recv(1024)
    if resp == "bad":
        print("Invalid Command\n")
        exit(1)
    if sys.argv[3] == "-g":
        sockit. send(sys.argv[4])
        resp = sockit.recv(1024)
        if resp != "File found":
            print("Not found")
            return
    d_sockit = setup_socket()
    if sys.argv[3] == "-l":
        get_flist(d_sockit)
    elif sys.argv[3] == "-g":
        get_file(d_sockit)
    d_sockit.close()

def connecto():
    sname = sys.argv[1] + ".engr.oregonstate.edu"
    s_port = int(sys.argv[2])
    sockit = socket(AF_INET, SOCK_STREAM)
    sockit.connect((sname, s_port))
    return sockit

if __name__ == "__main__":
    verify_inputs()
    sockit = connecto()
    send_rec(sockit)